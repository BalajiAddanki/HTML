import { Component, Input, OnChanges, OnInit, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { Topic, Chapter } from '../../models/repair-manual.model';

@Component({
  selector: 'app-nested-expansion-panel',
  templateUrl: './nested-expansion-panel.component.html'
})
export class NestedExpansionPanelComponent implements OnInit, OnChanges {

  @Input() parentTopic: Topic;
  @Input() chapter: Chapter;
  @Output() addNestedTopicHandler = new EventEmitter<any>();
  @Output() loadSubTopicsHandler = new EventEmitter<any>();
  @Output() deleteNestedTopicHandler = new EventEmitter<any>();
  @Output() viewFile = new EventEmitter<any>();
  @Output() editTopicHandler = new EventEmitter<any>();

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.topics) {
      this.parentTopic = changes.topics.currentValue;
    }
  }

  constructor() {
  }

  ngOnInit(): void {
  }

  addNestedTopic(chapterId: number, topic: Topic) {
    this.addNestedTopicHandler.emit({ chapterId: chapterId, topic: topic });
  }

  loadSubTopics(topicId: number) {
    this.loadSubTopicsHandler.emit({ chapterId: this.chapter.id, topicId: topicId });
  }

  addNestedTopicEventHandler(data) {
    this.addNestedTopicHandler.emit(data);
  }

  loadSubTopicsEventHandler(data) {
    this.loadSubTopicsHandler.emit(data);
  }

  deleteTopic($event, chapter: Chapter, topic: Topic) {
    if ($event) {
      $event.stopPropagation();
    }

    this.deleteNestedTopicHandler.emit({ chapter: chapter, topic: topic });
  }

  deleteNestedTopicEventHandler(data: { chapter: Chapter, topic: Topic }) {
    this.deleteNestedTopicHandler.emit({ chapter: data.chapter, topic: data.topic });
  }

  fileViewer(topic: Topic) {
    this.viewFile.emit(topic);
  }

  fileViewHandler(topic: Topic) {
    this.viewFile.emit(topic);
  }

  editTopic($event, chapter: Chapter, topic: Topic, parentTopic: Topic) {
    if ($event) {
      $event.stopPropagation();
    }

    this.editTopicHandler.emit({ chapterId: chapter.id, topic: topic, parentTopic:parentTopic });
  }

  editTopicEventHandler(data) {
    this.editTopicHandler.emit(data);
  }
}
